#coding:utf-8

import monitor as m
import datetime
import random

# create the database
m.db.create_all()


# create the site info
s1 = m.Site("Test Site 1", 116.5, 39.915)
s2 = m.Site("Test Site 2", 116.4, 39.915)
s3 = m.Site("Test Site 3", 116.3, 39.915)
s4 = m.Site("Test Site 4", 116.45, 40)
s5 = m.Site("Test Site 5", 116.4, 40)

m.db.session.add(s1)
m.db.session.add(s2)
m.db.session.add(s3)
m.db.session.add(s4)
m.db.session.add(s5)


# create record
for site_id in range(1, 6):
    for i in range(20):
        v = round(random.random() * 10, 2)
        r = m.Record(v, datetime.datetime.now(), site_id)
        m.db.session.add(r)

m.db.session.commit()
