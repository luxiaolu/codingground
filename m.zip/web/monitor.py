from flask import Flask
from flask import request
from flask import jsonify
from flask_sqlalchemy import SQLAlchemy
import datetime
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/zhai/wsp/web/data.db'
db = SQLAlchemy(app)


class Site(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True)
    longitude = db.Column(db.Float)
    latitude = db.Column(db.Float)

    records = db.relationship('Record', backref='site')

    def __init__(self, name, longitude, latitude):
        self.name = name
        self.longitude = longitude
        self.latitude = latitude

    def __repr__(self):
        return '<Name: %r\n  %f, %f>'%(self.name, self.longitude, self.latitude)

    def to_json(self):
        return {
            'id': self.id,
            'name': self.name,
            'longitude': self.longitude,
            'latitude': self.latitude
        }


class Record(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    co = db.Column(db.Float)
    date = db.Column(db.DateTime)
    site_id = db.Column(db.Integer, db.ForeignKey('site.id'))

    def __init__(self, co, date, site_id):
        self.co = co
        self.date = date
        self.site_id = site_id

    def __repr__(self):
        return '<CO: %f, %s>'%(self.co, self.date.strftime("%Y-%m-%d %H:%M:%S"))

    def to_json(self):
        return {
            'id': self.id,
            'co': self.co,
            'date': self.date.strftime("%Y-%m-%d %H:%M:%S")
        }


@app.route("/add_record", methods=['POST'])
def add_record():
    co = request.form['co']
    date = datetime.datetime.utcnow()
    site_id = request.form['site_id']
    record = Record(co, date, site_id)
    db.session.add(record)
    db.session.commit()
    return ""


@app.route("/get_records", methods=['GET'])
def get_records():
    site_id = request.args.get('site_id', "")
    count_str = request.args.get('count', "")
    if site_id:
        site = Site.query.filter_by(id=int(site_id)).first()

        count = -1
        if count_str and count_str.isdigit():
            count = int(count_str) * -1
        records = site.records[count:]
        return jsonify([r.to_json() for r in records])
    else:
        return ""


@app.route("/get_sites", methods=['GET'])
def get_sites():
    sites = Site.query.all()
    return jsonify([s.to_json() for s in sites])


@app.route("/update_gps", methods=['POST'])
def update_gps():
    site_id = request.form['site_id']
    longitude_str = request.form['longitude']
    latitude_str = request.form['latitude']
    if site_id:
        site = Site.query.filter_by(id=int(site_id)).first()
        if longitude_str and latitude_str:
            site.longitude = float(longitude_str)
            site.latitude = float(latitude_str)
            db.session.commit()
    return ""


@app.route("/")
def index():
    return "hello"

if __name__ == "__main__":
    app.run()
